import cv2
import numpy as np
import pytesseract
from PIL import Image


def preprocess_image(image: Image.Image):
    """Prepare the uploaded image for OCR."""
    image_array = np.array(image.convert("RGB"))

    gray = cv2.cvtColor(image_array, cv2.COLOR_RGB2GRAY)
    gray = cv2.GaussianBlur(gray, (3, 3), 0)

    threshold = cv2.threshold(
        gray,
        0,
        255,
        cv2.THRESH_BINARY + cv2.THRESH_OTSU
    )[1]

    return threshold


def extract_text(image: Image.Image) -> str:
    """Extract text from an image using Tesseract OCR."""
    processed = preprocess_image(image)

    text = pytesseract.image_to_string(
        processed,
        config="--psm 6"
    )

    return text.strip()
