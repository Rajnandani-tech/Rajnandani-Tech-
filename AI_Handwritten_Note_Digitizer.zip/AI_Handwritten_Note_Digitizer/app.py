import streamlit as st
from PIL import Image
from ocr import extract_text

st.set_page_config(
    page_title="AI Handwritten Note Digitizer",
    page_icon="📝",
    layout="centered"
)

st.title("📝 AI Handwritten Note Digitizer")
st.write("Convert a handwritten note image into editable digital text using OCR.")

uploaded_file = st.file_uploader(
    "Upload your handwritten note",
    type=["jpg", "jpeg", "png"]
)

if uploaded_file:
    image = Image.open(uploaded_file)

    st.subheader("Uploaded Note")
    st.image(image, caption="Handwritten Note", use_container_width=True)

    if st.button("✨ Convert to Digital Text"):
        with st.spinner("Processing the note..."):
            text = extract_text(image)

        st.subheader("📄 Digital Text")

        edited_text = st.text_area(
            "Edit the extracted text if needed:",
            value=text,
            height=300
        )

        st.download_button(
            "💾 Download Text File",
            data=edited_text,
            file_name="digital_notes.txt",
            mime="text/plain"
        )

        if edited_text.strip():
            st.success("Text extraction completed!")
        else:
            st.warning(
                "No readable text was detected. Try a clearer, well-lit image."
            )
